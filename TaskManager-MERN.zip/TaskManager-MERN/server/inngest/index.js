import { Inngest } from "inngest";
import Task from "../models/Task.js";
import sendEmail from "../config/nodemailer.js";

// Create a client to send and receive events
export const inngest = new Inngest({ id: "task-management-system" });

// Notify employee by email when a new task is assigned to them
const taskAssignedNotification = inngest.createFunction(
  { id: "task-assigned-notification", triggers: [{ event: "task/created" }] },
  async ({ event }) => {
    const { taskId } = event.data;
    const task = await Task.findById(taskId).populate("assignedTo");
    if (!task || !task.assignedTo?.email) return;

    await sendEmail({
      to: task.assignedTo.email,
      subject: "New Task Assigned",
      body: `<div style="max-width: 600px;">
              <h2>Hi ${task.assignedTo.firstName}, 👋</h2>
              <p style="font-size: 16px;">A new task has been assigned to you:</p>
              <p style="font-size: 18px; font-weight: bold; color: #007bff; margin: 8px 0;">${task.title}</p>
              <p style="font-size: 16px;">Priority: ${task.priority}</p>
              <p style="font-size: 16px;">Due: ${task.dueDate.toLocaleDateString()}</p>
              <br />
              <p style="font-size: 16px;">Best Regards,</p>
              <p style="font-size: 16px;">Task Manager</p>
            </div>`,
    });
  },
);

// Cron: Every morning at 9 AM IST, email employees about tasks that are now overdue
const overdueTaskReminderCron = inngest.createFunction(
  { id: "overdue-task-reminder-cron", triggers: [{ cron: "TZ=Asia/Kolkata 0 9 * * *" }] },
  async ({ step }) => {
    // Step 1: Find tasks that are overdue and not completed
    const overdueTasks = await step.run("get-overdue-tasks", async () => {
      const tasks = await Task.find({
        status: { $ne: "COMPLETED" },
        dueDate: { $lt: new Date() },
      }).populate("assignedTo").lean();
      return tasks;
    });

    // Step 2: Send reminder emails
    if (overdueTasks.length > 0) {
      await step.run("send-overdue-emails", async () => {
        const emailPromises = overdueTasks
          .filter((task) => task.assignedTo?.email)
          .map((task) =>
            sendEmail({
              to: task.assignedTo.email,
              subject: "Overdue Task Reminder",
              body: `<div style="max-width: 600px; font-family: Arial, sans-serif;">
                      <h2>Hi ${task.assignedTo.firstName}, 👋</h2>
                      <p style="font-size: 16px;">The following task is now overdue:</p>
                      <p style="font-size: 18px; font-weight: bold; color: #e11d48; margin: 8px 0;">${task.title}</p>
                      <p style="font-size: 16px;">Was due: ${new Date(task.dueDate).toLocaleDateString()}</p>
                      <p style="font-size: 16px;">Please update its status as soon as possible.</p>
                      <br />
                      <p style="font-size: 16px;">Best Regards,</p>
                      <p style="font-size: 16px;"><strong>Task Manager</strong></p>
                    </div>`,
            }),
          );
        await Promise.all(emailPromises);
        return { emailsSent: emailPromises.length };
      });
    }

    return { overdueCount: overdueTasks.length };
  },
);

// Create an empty array where we'll export future Inngest functions
export const functions = [taskAssignedNotification, overdueTaskReminderCron];
