import mongoose from "mongoose";

const taskSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, default: "" },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
    assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    priority: { type: String, enum: ["LOW", "MEDIUM", "HIGH", "URGENT"], default: "MEDIUM" },
    status: { type: String, enum: ["TODO", "IN_PROGRESS", "COMPLETED", "BLOCKED"], default: "TODO" },
    category: { type: String, default: "" },
    dueDate: { type: Date, required: true },
    completedAt: { type: Date, default: null },
}, {timestamps: true})

const Task = mongoose.models.Task || mongoose.model("Task", taskSchema)

export default Task;
