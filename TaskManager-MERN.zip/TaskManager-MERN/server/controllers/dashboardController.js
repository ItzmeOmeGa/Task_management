import { DEPARTMENTS } from "../constants/departments.js";
import Employee from "../models/Employee.js";
import Task from "../models/Task.js";

// Get dashboard for employee and admin
// GET /api/dashboard
export const getDashboard = async (req, res) => {
    try {
        const session = req.session;
        if (session.role === "ADMIN") {
            const [totalEmployees, totalTasks, todoCount, inProgressCount, completedCount, overdueCount] = await Promise.all([
                Employee.countDocuments({ isDeleted: { $ne: true } }),
                Task.countDocuments(),
                Task.countDocuments({ status: "TODO" }),
                Task.countDocuments({ status: "IN_PROGRESS" }),
                Task.countDocuments({ status: "COMPLETED" }),
                Task.countDocuments({ status: { $ne: "COMPLETED" }, dueDate: { $lt: new Date() } }),
            ]);

            return res.json({
                role: "ADMIN",
                totalEmployees,
                totalDepartments: DEPARTMENTS.length,
                totalTasks,
                todoCount,
                inProgressCount,
                completedCount,
                overdueCount,
            });
        } else {
            const employee = await Employee.findOne({ userId: session.userId }).lean();
            if (!employee) return res.status(404).json({ error: "Employee not found" });

            const [myTasks, myTodo, myInProgress, myCompleted, myOverdue] = await Promise.all([
                Task.countDocuments({ assignedTo: employee._id }),
                Task.countDocuments({ assignedTo: employee._id, status: "TODO" }),
                Task.countDocuments({ assignedTo: employee._id, status: "IN_PROGRESS" }),
                Task.countDocuments({ assignedTo: employee._id, status: "COMPLETED" }),
                Task.countDocuments({ assignedTo: employee._id, status: { $ne: "COMPLETED" }, dueDate: { $lt: new Date() } }),
            ]);

            const upcomingTasks = await Task.find({
                assignedTo: employee._id,
                status: { $ne: "COMPLETED" },
            }).sort({ dueDate: 1 }).limit(5).lean();

            return res.json({
                role: "EMPLOYEE",
                employee: { ...employee, id: employee._id.toString() },
                myTasks,
                myTodo,
                myInProgress,
                myCompleted,
                myOverdue,
                upcomingTasks: upcomingTasks.map((t) => ({ ...t, id: t._id.toString() })),
            });
        }
    } catch (error) {
        console.error("Dashboard error:", error);
        return res.status(500).json({ error: "Failed" });
    }
};
