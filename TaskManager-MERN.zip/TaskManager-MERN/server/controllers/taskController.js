import { inngest } from "../inngest/index.js";
import Task from "../models/Task.js";
import Employee from "../models/Employee.js";

// Create task (Admin assigns a task to an employee)
// POST /api/tasks
export const createTask = async (req, res) => {
    try {
        const { title, description, assignedTo, priority, dueDate, category } = req.body;

        if (!title || !assignedTo || !dueDate) {
            return res.status(400).json({ error: "Title, assignee, and due date are required" });
        }

        const employee = await Employee.findById(assignedTo);
        if (!employee) return res.status(404).json({ error: "Assigned employee not found" });

        const task = await Task.create({
            title,
            description: description || "",
            assignedTo,
            assignedBy: req.session.userId,
            priority: priority || "MEDIUM",
            dueDate: new Date(dueDate),
            category: category || "",
        });

        await inngest.send({
            name: "task/created",
            data: { taskId: task._id.toString() },
        });

        return res.status(201).json({ success: true, data: task });
    } catch (error) {
        console.error("Create task error:", error);
        return res.status(500).json({ error: "Failed to create task" });
    }
};

// Get tasks
// GET /api/tasks
export const getTasks = async (req, res) => {
    try {
        const session = req.session;
        const isAdmin = session.role === "ADMIN";

        if (isAdmin) {
            const { status, priority, assignedTo } = req.query;
            const where = {};
            if (status) where.status = status;
            if (priority) where.priority = priority;
            if (assignedTo) where.assignedTo = assignedTo;

            const tasks = await Task.find(where)
                .populate("assignedTo", "firstName lastName position department")
                .populate("assignedBy", "email")
                .sort({ createdAt: -1 });

            const data = tasks.map((t) => {
                const obj = t.toObject();
                return { ...obj, id: obj._id.toString() };
            });

            return res.json({ data });
        } else {
            const employee = await Employee.findOne({ userId: session.userId }).lean();
            if (!employee) return res.status(404).json({ error: "Employee not found" });

            const { status } = req.query;
            const where = { assignedTo: employee._id };
            if (status) where.status = status;

            const tasks = await Task.find(where)
                .populate("assignedBy", "email")
                .sort({ dueDate: 1 });

            return res.json({
                data: tasks,
                employee: { ...employee, id: employee._id.toString() },
            });
        }
    } catch (error) {
        console.error("Get tasks error:", error);
        return res.status(500).json({ error: "Failed to fetch tasks" });
    }
};

// Update task status (Employee updates their own task's progress; Admin can update any)
// PATCH /api/tasks/:id/status
export const updateTaskStatus = async (req, res) => {
    try {
        const { status } = req.body;
        if (!["TODO", "IN_PROGRESS", "COMPLETED", "BLOCKED"].includes(status)) {
            return res.status(400).json({ error: "Invalid status" });
        }

        const task = await Task.findById(req.params.id);
        if (!task) return res.status(404).json({ error: "Task not found" });

        const session = req.session;
        if (session.role !== "ADMIN") {
            const employee = await Employee.findOne({ userId: session.userId });
            if (!employee || task.assignedTo.toString() !== employee._id.toString()) {
                return res.status(403).json({ error: "You can only update your own tasks" });
            }
        }

        task.status = status;
        task.completedAt = status === "COMPLETED" ? new Date() : null;
        await task.save();

        return res.json({ success: true, data: task });
    } catch (error) {
        return res.status(500).json({ error: "Failed to update task" });
    }
};

// Update task details (Admin)
// PUT /api/tasks/:id
export const updateTask = async (req, res) => {
    try {
        const { title, description, assignedTo, priority, dueDate, category, status } = req.body;

        const task = await Task.findById(req.params.id);
        if (!task) return res.status(404).json({ error: "Task not found" });

        if (assignedTo) {
            const employee = await Employee.findById(assignedTo);
            if (!employee) return res.status(404).json({ error: "Assigned employee not found" });
            task.assignedTo = assignedTo;
        }

        if (title !== undefined) task.title = title;
        if (description !== undefined) task.description = description;
        if (priority !== undefined) task.priority = priority;
        if (category !== undefined) task.category = category;
        if (dueDate !== undefined) task.dueDate = new Date(dueDate);
        if (status !== undefined) {
            task.status = status;
            task.completedAt = status === "COMPLETED" ? new Date() : null;
        }

        await task.save();
        return res.json({ success: true, data: task });
    } catch (error) {
        return res.status(500).json({ error: "Failed to update task" });
    }
};

// Delete task (Admin)
// DELETE /api/tasks/:id
export const deleteTask = async (req, res) => {
    try {
        const task = await Task.findByIdAndDelete(req.params.id);
        if (!task) return res.status(404).json({ error: "Task not found" });
        return res.json({ success: true });
    } catch (error) {
        return res.status(500).json({ error: "Failed to delete task" });
    }
};
