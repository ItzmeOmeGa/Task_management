import { Router } from "express";
import { protect, protectAdmin } from "../middleware/auth.js";
import { createTask, deleteTask, getTasks, updateTask, updateTaskStatus } from "../controllers/taskController.js";

const taskRouter = Router();

taskRouter.get("/", protect, getTasks);
taskRouter.post("/", protect, protectAdmin, createTask);
taskRouter.put("/:id", protect, protectAdmin, updateTask);
taskRouter.patch("/:id/status", protect, updateTaskStatus);
taskRouter.delete("/:id", protect, protectAdmin, deleteTask);

export default taskRouter;
