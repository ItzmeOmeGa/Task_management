import { useCallback, useEffect, useState } from "react"
import { Plus, X } from "lucide-react"
import api from "../api/axios"
import toast from "react-hot-toast"
import { useAuth } from "../context/AuthContext"
import { STATUSES, STATUS_LABELS, PRIORITIES, PRIORITY_LABELS } from "../assets/assets"
import TaskCard from "../components/task/TaskCard"
import TaskForm from "../components/task/TaskForm"

const Tasks = () => {
    const { user } = useAuth()
    const isAdmin = user?.role === "ADMIN"

    const [tasks, setTasks] = useState([])
    const [loading, setLoading] = useState(true)
    const [statusFilter, setStatusFilter] = useState("")
    const [priorityFilter, setPriorityFilter] = useState("")
    const [showCreateModal, setShowCreateModal] = useState(false)
    const [editTask, setEditTask] = useState(null)

    const fetchTasks = useCallback(async () => {
        try {
            const params = new URLSearchParams()
            if (statusFilter) params.set("status", statusFilter)
            if (priorityFilter && isAdmin) params.set("priority", priorityFilter)
            const { data } = await api.get(`/tasks?${params.toString()}`)
            setTasks(data.data || [])
        } catch (error) {
            toast.error(error.response?.data?.error || error.message)
        } finally {
            setLoading(false)
        }
    }, [statusFilter, priorityFilter, isAdmin])

    useEffect(() => {
        fetchTasks()
    }, [fetchTasks])

    const handleStatusChange = async (taskId, status) => {
        try {
            await api.patch(`/tasks/${taskId}/status`, { status })
            fetchTasks()
        } catch (error) {
            toast.error(error.response?.data?.error || error.message)
        }
    }

    const handleDelete = async (taskId) => {
        if (!confirm("Delete this task?")) return
        try {
            await api.delete(`/tasks/${taskId}`)
            toast.success("Task deleted")
            fetchTasks()
        } catch (error) {
            toast.error(error.response?.data?.error || error.message)
        }
    }

    const filteredByPriority = priorityFilter && !isAdmin
        ? tasks.filter((t) => t.priority === priorityFilter)
        : tasks

    return (
        <div className="animate-fade-in">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                <div>
                    <h1 className="page-title">{isAdmin ? "Manage Tasks" : "My Tasks"}</h1>
                    <p className="page-subtitle">
                        {isAdmin ? "Assign and track tasks across your team" : "Track and update your assigned tasks"}
                    </p>
                </div>
                {isAdmin && (
                    <button onClick={() => setShowCreateModal(true)} className="btn-primary flex items-center gap-2 w-full sm:w-auto justify-center">
                        <Plus size={16} /> New Task
                    </button>
                )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="max-w-48">
                    <option value="">All Statuses</option>
                    {STATUSES.map((s) => (
                        <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                    ))}
                </select>
                <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)} className="max-w-48">
                    <option value="">All Priorities</option>
                    {PRIORITIES.map((p) => (
                        <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                    ))}
                </select>
            </div>

            {loading ? (
                <div className="flex justify-center p-12">
                    <div className="animate-spin h-8 w-8 border-2 border-indigo-600 border-t-transparent rounded-full" />
                </div>
            ) : filteredByPriority.length === 0 ? (
                <p className="text-center py-16 text-slate-400 bg-white rounded-2xl border border-dashed border-slate-200">
                    No tasks found
                </p>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5">
                    {filteredByPriority.map((task) => (
                        <TaskCard
                            key={task.id || task._id}
                            task={task}
                            isAdmin={isAdmin}
                            onStatusChange={handleStatusChange}
                            onEdit={setEditTask}
                            onDelete={handleDelete}
                        />
                    ))}
                </div>
            )}

            {/* Create Task Modal */}
            {showCreateModal && (
                <div className="fixed bg-black/40 backdrop-blur-sm inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto" onClick={() => setShowCreateModal(false)}>
                    <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-xl my-8 animate-fade-in" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-between p-6 pb-0">
                            <div>
                                <h2 className="text-lg font-semibold text-slate-900">New Task</h2>
                                <p className="text-sm text-slate-500 mt-0.5">Assign a task to a team member</p>
                            </div>
                            <button onClick={() => setShowCreateModal(false)} className="p-2 rounded-lg hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="p-6">
                            <TaskForm
                                onSuccess={() => {
                                    setShowCreateModal(false)
                                    toast.success("Task created")
                                    fetchTasks()
                                }}
                                onCancel={() => setShowCreateModal(false)}
                            />
                        </div>
                    </div>
                </div>
            )}

            {/* Edit Task Modal */}
            {editTask && (
                <div className="fixed bg-black/40 backdrop-blur-sm inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto" onClick={() => setEditTask(null)}>
                    <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-xl my-8 animate-fade-in" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-between p-6 pb-0">
                            <div>
                                <h2 className="text-lg font-semibold text-slate-900">Edit Task</h2>
                                <p className="text-sm text-slate-500 mt-0.5">Update task details</p>
                            </div>
                            <button onClick={() => setEditTask(null)} className="p-2 rounded-lg hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="p-6">
                            <TaskForm
                                initialData={editTask}
                                onSuccess={() => {
                                    setEditTask(null)
                                    toast.success("Task updated")
                                    fetchTasks()
                                }}
                                onCancel={() => setEditTask(null)}
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

export default Tasks
