import { AlertTriangleIcon, ArrowRightIcon, CheckCircle2Icon, ClockIcon, ListTodoIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

const EmployeeDashboard = ({data}) => {
    const emp = data.employee;

    const cards = [
        {
            icon: ListTodoIcon,
            value: data.myTodo,
            title: "To Do",
            subtitle: "Not started yet",
        },
        {
            icon: ClockIcon,
            value: data.myInProgress,
            title: "In Progress",
            subtitle: "Currently working on",
        },
        {
            icon: CheckCircle2Icon,
            value: data.myCompleted,
            title: "Completed",
            subtitle: "Wrapped up",
        },
        {
            icon: AlertTriangleIcon,
            value: data.myOverdue,
            title: "Overdue",
            subtitle: "Needs attention",
        },
    ]

  return (
    <div className="animate-fade-in">
        <div className="page-header">
            <h1 className='page-title'>Welcome, {emp?.firstName}!</h1>
            <p className="page-subtitle">
                {emp?.position} - {emp?.department || "No Department"}
            </p>
        </div>

        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 mb-8'>
            {cards.map((card, index)=>(
                <div key={index} className='card card-hover p-5 sm:p-6 relative overflow-hidden group flex items-center justify-between'>
                    <div>
                        <div className="absolute left-0 top-0 bottom-0 w-1 rounded-r-full bg-slate-500/70 group-hover:bg-indigo-500/70"/>
                        <p className='text-sm font-medium text-slate-700'>{card.title}</p>
                        <p className='text-2xl font-bold text-slate-900 mt-1'>{card.value}</p>
                    </div>
                    <card.icon className='size-10 p-2.5 rounded-lg bg-slate-100  text-slate-600 group-hover:bg-indigo-50  group-hover:text-indigo-600 transition-colors duration-200'/>
                </div>
            ))}
        </div>

        {data.upcomingTasks?.length > 0 && (
            <div className='card p-5 sm:p-6 mb-8'>
                <h2 className='font-medium text-slate-900 mb-4'>Upcoming Tasks</h2>
                <div className='divide-y divide-slate-100'>
                    {data.upcomingTasks.map((task)=>(
                        <div key={task.id} className='py-3 flex items-center justify-between gap-3'>
                            <div>
                                <p className='text-sm font-medium text-slate-800'>{task.title}</p>
                                <p className='text-xs text-slate-500 mt-0.5'>Due {new Date(task.dueDate).toLocaleDateString()}</p>
                            </div>
                            <span className='badge bg-slate-100 text-slate-600'>{task.priority}</span>
                        </div>
                    ))}
                </div>
            </div>
        )}

        <Link to="/tasks" className='btn-primary text-center inline-flex items-center justify-center gap-2'>
            View My Tasks <ArrowRightIcon className="w-4 h-4" />
        </Link>

    </div>
  )
}

export default EmployeeDashboard
