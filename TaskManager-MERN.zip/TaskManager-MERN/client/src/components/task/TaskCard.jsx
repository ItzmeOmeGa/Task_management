import { CalendarIcon, PencilIcon, Trash2Icon, UserIcon } from 'lucide-react'
import { STATUS_LABELS } from '../../assets/assets'

const PRIORITY_STYLES = {
    LOW: "bg-slate-100 text-slate-600 ring-1 ring-slate-500/10",
    MEDIUM: "bg-blue-50 text-blue-700 ring-1 ring-blue-600/10",
    HIGH: "badge-warning",
    URGENT: "badge-danger",
}

const TaskCard = ({ task, isAdmin, onStatusChange, onEdit, onDelete }) => {
    const isOverdue = task.status !== "COMPLETED" && new Date(task.dueDate) < new Date()

    return (
        <div className="card card-hover p-4 sm:p-5 relative">
            <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="text-sm font-medium text-slate-900 leading-snug">{task.title}</h3>
                <span className={`badge shrink-0 ${PRIORITY_STYLES[task.priority] || PRIORITY_STYLES.MEDIUM}`}>
                    {task.priority}
                </span>
            </div>

            {task.description && (
                <p className="text-xs text-slate-500 mb-3 line-clamp-2">{task.description}</p>
            )}

            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mb-4">
                <span className={`flex items-center gap-1.5 ${isOverdue ? "text-rose-600 font-medium" : ""}`}>
                    <CalendarIcon className="w-3.5 h-3.5" />
                    {new Date(task.dueDate).toLocaleDateString()}
                    {isOverdue && " (overdue)"}
                </span>
                {isAdmin && task.assignedTo && (
                    <span className="flex items-center gap-1.5">
                        <UserIcon className="w-3.5 h-3.5" />
                        {task.assignedTo.firstName} {task.assignedTo.lastName}
                    </span>
                )}
                {task.category && (
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600">{task.category}</span>
                )}
            </div>

            <div className="flex items-center justify-between gap-2">
                <select
                    value={task.status}
                    onChange={(e) => onStatusChange(task.id || task._id, e.target.value)}
                    className="text-xs py-1.5! px-2.5! w-auto max-w-40"
                >
                    {Object.entries(STATUS_LABELS).map(([value, label]) => (
                        <option key={value} value={value}>{label}</option>
                    ))}
                </select>

                {isAdmin && (
                    <div className="flex items-center gap-1">
                        <button onClick={() => onEdit(task)} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors">
                            <PencilIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => onDelete(task.id || task._id)} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors">
                            <Trash2Icon className="w-4 h-4" />
                        </button>
                    </div>
                )}
            </div>
        </div>
    )
}

export default TaskCard
