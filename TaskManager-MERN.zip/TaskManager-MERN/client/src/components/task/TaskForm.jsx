import { useEffect, useState } from "react"
import { Loader2Icon } from "lucide-react"
import { PRIORITIES, PRIORITY_LABELS } from "../../assets/assets"
import api from "../../api/axios"
import toast from "react-hot-toast"

const TaskForm = ({ initialData, onSuccess, onCancel }) => {
    const [loading, setLoading] = useState(false)
    const [employees, setEmployees] = useState([])
    const isEditMode = !!initialData

    useEffect(() => {
        api.get("/employees").then(({ data }) => setEmployees(data.filter((e) => !e.isDeleted)))
            .catch(() => toast.error("Failed to load employees"))
    }, [])

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        const formData = new FormData(e.currentTarget)
        const payload = Object.fromEntries(formData.entries())

        try {
            if (isEditMode) {
                await api.put(`/tasks/${initialData.id || initialData._id}`, payload)
            } else {
                await api.post("/tasks", payload)
            }
            onSuccess ? onSuccess() : null
        } catch (error) {
            toast.error(error.response?.data?.error || error.message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-5 text-sm text-slate-700">
            <div>
                <label className="block mb-2">Title</label>
                <input name="title" required defaultValue={initialData?.title} placeholder="e.g. Prepare Q3 report" />
            </div>

            <div>
                <label className="block mb-2">Description</label>
                <textarea name="description" rows={3} className="resize-none" defaultValue={initialData?.description} placeholder="Task details..." />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label className="block mb-2">Assign To</label>
                    <select name="assignedTo" required defaultValue={initialData?.assignedTo?._id || initialData?.assignedTo || ""}>
                        <option value="" disabled>Select employee</option>
                        {employees.map((emp) => (
                            <option key={emp.id} value={emp.id}>{emp.firstName} {emp.lastName} — {emp.position}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label className="block mb-2">Priority</label>
                    <select name="priority" defaultValue={initialData?.priority || "MEDIUM"}>
                        {PRIORITIES.map((p) => (
                            <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label className="block mb-2">Due Date</label>
                    <input type="date" name="dueDate" required defaultValue={initialData?.dueDate ? new Date(initialData.dueDate).toISOString().split("T")[0] : ""} />
                </div>
                <div>
                    <label className="block mb-2">Category (Optional)</label>
                    <input name="category" defaultValue={initialData?.category} placeholder="e.g. Onboarding" />
                </div>
            </div>

            <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-2">
                <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
                <button type="submit" disabled={loading} className="btn-primary flex items-center justify-center">
                    {loading && <Loader2Icon className="w-4 h-4 mr-2 animate-spin" />}
                    {isEditMode ? "Update Task" : "Create Task"}
                </button>
            </div>
        </form>
    )
}

export default TaskForm
