export const DEPARTMENTS = ["Engineering", "Human Resources", "Marketing", "Sales", "Finance", "Operations", "IT Support", "Customer Success", "Product Management", "Design"];

export const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "URGENT"];

export const STATUSES = ["TODO", "IN_PROGRESS", "COMPLETED", "BLOCKED"];

export const STATUS_LABELS = {
    TODO: "To Do",
    IN_PROGRESS: "In Progress",
    COMPLETED: "Completed",
    BLOCKED: "Blocked",
};

export const PRIORITY_LABELS = {
    LOW: "Low",
    MEDIUM: "Medium",
    HIGH: "High",
    URGENT: "Urgent",
};
